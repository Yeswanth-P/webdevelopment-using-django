

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import DoctorForm, PatientForm, AppointmentForm, PatientDischargeForm
from .models import Doctor, Patient, Appointment, PatientDischargeDetails
from django.db import IntegrityError
from django.contrib.auth.decorators import login_required



# Create your views here.
def boot(request):
    return render(request,'boot.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def home(request):
    return render(request,'home.html')

def Index(request):
    if not request.user.is_staff:
        return redirect('login')
    return render(request,'index.html')

def home(request):
    return render(request, 'home.html')

def add_doctor(request):
    form = DoctorForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'form.html', {'form': form, 'title': 'Add Doctor'})

def add_patient(request):
    form = PatientForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'form.html', {'form': form, 'title': 'Add Patient'})

def book_appointment(request):
    form = AppointmentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'form.html', {'form': form, 'title': 'Book Appointment'})

def discharge_patient(request):
    form = PatientDischargeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'form.html', {'form': form, 'title': 'Discharge Patient'})


@login_required
def patient_dashboard(request):
    patient = Patient.objects.get(user=request.user)
    discharges = PatientDischargeDetails.objects.filter(patientName=patient.user.username)

    form = AppointmentForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.patient = patient 
            appointment.save()
            messages.success(request, "Appointment booked successfully!")
            return redirect('home')


    return render(request, 'patient_dashboard.html', {
        'patient': patient,
        'discharges': discharges,
        'form': form,
    })



def patient_register(request):
    if request.method == 'POST':
        username = request.POST['name']
        gender = request.POST['gender']
        age = request.POST['age']
        phone = request.POST['phone']
        address = request.POST['address']
        mail = request.POST.get('mail')


        password = request.POST['password']

        try:
            user = User.objects.create_user(username=username, password=password)
            patient = Patient.objects.create(
                user=user,
                gender=gender,
                age=age,
                phone=phone,
                address=address,
                mail=mail
            )
            return redirect('patient_login')
        except IntegrityError:
            messages.error(request, "Username already exists. Please try a different name.")
    
    return render(request, 'patient_register.html')




def patient_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('patient_dashboard')  
        else:
            messages.error(request, 'Invalid credentials')

    return render(request, 'patient_login.html')

def patient_logout(request):
    logout(request)
    return redirect('home')


@login_required
def doctor_dashboard(request):
    try:
        doctor = Doctor.objects.get(user=request.user)
    except Doctor.DoesNotExist:
        messages.error(request, "No doctor profile found.")
        return redirect('doctor_login')

    appointments = Appointment.objects.filter(doctor=doctor).select_related('patient', 'patient__user')

    return render(request, 'doctor_dashboard.html', {
        'doctor': doctor,
        'appointments': appointments,
    })



def doctor_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            try:
            
                Doctor.objects.get(user=user)
                login(request, user)
                return redirect('doctor_dashboard')
            except Doctor.DoesNotExist:
                messages.error(request, 'You are not registered as a doctor.')
        else:
            messages.error(request, 'Invalid credentials')

    return render(request, 'doctor_login.html')

